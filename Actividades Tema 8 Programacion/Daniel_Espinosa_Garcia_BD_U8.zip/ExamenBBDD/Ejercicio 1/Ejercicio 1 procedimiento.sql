CREATE DEFINER=`root`@`localhost` PROCEDURE `frecuencia_nombres`(in nom varchar(50), out porct int)
BEGIN

declare idn int;

-- si el nombre es de hombre
if (select nombre from nombreshombre where nombre = nom) is not null then

-- almacena el id del nombre en una variable
set idn = (select idnombre from nombreshombre where nombre = nom);
-- almacena la frecuencia para devolverla como parametro
set porct = (select frecnombre from nombreshombre where idnombre = idn);

-- si el nombre es de mujer
elseif (select nombre from nombresmujer where nombre = nom) is not null then

-- almacena el id del nombre en una variable
set idn = (select idnombre from nombresmujer where nombre = nom);
-- almacena la frecuencia para devolverla como parametro
set porct = (select frecnombre from nombresmujer where idnombre = idn);

-- si no existe el nombre
else

set porct = 0;

end if;

END