use datosorigen;

-- Ejercicio 1

set @proc = 0;

call frecuencia_nombres('Daniela',@proc);

select @proc;

-- Ejercicio 2
select nombreAleatorio();


