CREATE DEFINER=`root`@`localhost` FUNCTION `nombreAleatorio`() RETURNS varchar(100) CHARSET utf8mb4
    DETERMINISTIC
BEGIN

declare sex int;
declare nom varchar(50);
declare porc int;
declare respuesta varchar(100);

-- seleccionamos un sexo al Azar 0 mujer 1 hombre
set sex = round(rand()*1);

-- si es hombre busca un nombre aleatorio de hombre
if	sex = 0 then
set nom = (select nombre from nombreshombre order by rand() limit 1);
else
set nom = (select nombre from nombresmujer order by rand() limit 1);
end if;

call frecuencia_nombres(nom,porc);

set respuesta = concat('Nombre: ' , nom,' - Porcentaje: ', porc);

RETURN respuesta;
END