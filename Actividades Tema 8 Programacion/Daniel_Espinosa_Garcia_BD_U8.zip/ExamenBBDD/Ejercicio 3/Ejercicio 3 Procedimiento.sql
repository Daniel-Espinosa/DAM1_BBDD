CREATE DEFINER=`root`@`localhost` PROCEDURE `borrarcontratos`(in n int)
BEGIN

declare aux int;
declare cont int;
set cont = 0;

if n <= (select count(numcontrato) from contratos) then

while cont <> n do

set aux = (select max(numcontrato) from contratos);

delete from contratos where numcontrato = aux;
set cont = cont + 1;
end while;

end if;



END