Use alquileres;

start transaction;
-- borro los contratos (lo meto en una transaction para poder revertir los cambios ;)
call borrarcontratos(3);
rollback;