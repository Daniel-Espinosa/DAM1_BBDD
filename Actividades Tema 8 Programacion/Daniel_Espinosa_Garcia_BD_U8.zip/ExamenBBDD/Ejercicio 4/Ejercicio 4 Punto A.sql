-- Ejercicio 4

-- punto A


delimiter //
CREATE trigger insertarEquipo after insert on equipos for each row
BEGIN

insert into clasificacion set codeq =new.codeq;

END//
delimiter ;