-- Ejercicio 4

-- Punto A

delimiter //
CREATE trigger insertarPartido before insert on partidos for each row

BEGIN

set new.golesloc=null;
set new.golesvis=null;


END//
delimiter ;