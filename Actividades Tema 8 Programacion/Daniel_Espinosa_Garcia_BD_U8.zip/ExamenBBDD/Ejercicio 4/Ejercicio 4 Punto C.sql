-- Ejercicio 4

-- Punto A

delimiter //
CREATE trigger insertarPartido before insert on partidos for each row

BEGIN

set new.golesloc=null;
set new.golesvis=null;

-- Si en la jornada ya hay algún partido que contiene a los equipos del partido a insertar, se debe hacer algo que impida la grabación del partido
if (select eqloc,eqvis from partidos where eqloc = new.eqloc and eqvis = new.eqvis) is not null then
set new.numjornada=null;
end if;


END//
delimiter ;