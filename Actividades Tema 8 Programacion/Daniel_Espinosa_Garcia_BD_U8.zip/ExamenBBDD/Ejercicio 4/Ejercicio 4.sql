Use ligatercera;

-- drop trigger insertarPartido;


-- Punto A
insert into equipos values (
'ZZZ','equipo prueba','Santander','Estadio1',null,null);

select * from clasificacion where codeq = 'ZZZ';

-- Punto B

insert into partidos values (
27,11,'ALB','BAR',4,3,curdate());

select * from partidos where eqloc = 'ALB' and eqvis = 'BAR';

-- Punto C

insert into partidos values (
27,11,'ALB','BAR',4,3,curdate());

-- Da fallo la insercion por el Triger que generamos ;)

